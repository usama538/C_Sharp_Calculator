﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Add(3, 5);
            Subtract(6, 5);
            Multiply(6, 5);
            Divide(23, 6);
            Factorial(3);
            Power(2, 5);
            Remainder(15, 5);
            Console.ReadLine();
        }

        //Addition Function
        static void Add(double x, double y)
        {
            Console.WriteLine("{0} + {1} = {2}", x, y, x + y);
        }

         //Subtract Function
         static void Subtract(double x , double y)
        {
            Console.WriteLine("{0} - {1} = {2}", x, y, x - y);
        }
        
        //Multiplay Function
        static void Multiply(double x,double y)
        {
            Console.WriteLine("{0} * {1} = {2}", x, y, x * y);
        }

        //Divide Function
        static void Divide(double x, double y)
        {
            Console.WriteLine("{0} / {1} = {2}", x, y, x / y);
        }

        //Factorial Function
        static void Factorial(int x)
        {
            if (x >= 0)
            {
                int fact = 1;
                for (int i = 1; i <= x; i++)
                {
                    fact *= i;
                }
                Console.WriteLine("{0}! = {1}", x, fact);
            }
        }

        //Power Function
        static void Power(int x, int y)
        {
            int temp = x;
            if (y > 0)
            {
                if (y == 1)
                {
                    Console.WriteLine("{0} raised to power {1} is {2}", x, y, x);
                }
                else
                {
                    for (int i = 1; i < y; i++)
                    {
                        temp *= x;
                    }
                    Console.WriteLine("{0} raised to power {1} is {2}", x, y, temp);
                }
            }
        }

        //Remainder Function
        static void Remainder(int x, int y)
        {
            int temp = x;
            if( x >= y )
            {
                while (temp >= y)
                {
                    temp -= y;
                }
                Console.WriteLine("{0} % {1} = {2}", x, y, temp);
            }
        }

    }
    }
    

